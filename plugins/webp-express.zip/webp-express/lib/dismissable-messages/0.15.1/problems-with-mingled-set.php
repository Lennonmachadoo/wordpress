<?php

namespace WebPExpress;

/*
DismissableMessages::printDismissableMessage(
    'error',
    'Sorry, due to a bug, the combination of having destination folder set to "mingled" and ' .
        'File extension set to "Set to .webp" ' .
        'does not currently work. Please change the settings. ' .
        'I shall fix this soon!',
    '0.15.1/problems-with-mingled-set',
    'Got it!'
);
*/
